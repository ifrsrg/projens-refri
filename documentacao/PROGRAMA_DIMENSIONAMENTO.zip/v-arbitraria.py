# -*- coding: utf-8 -*-
"""
___________________________________________________________

ROTINA DE CÁLCULO PARA DIMENSIONAMENTO DE DUTOS:
---------  VELOCIDADE ARBITRÁRIA  -----------
               (ou CONSTANTE)

LATEST: LABORATÓRIO TERMOFLUIDODINÂMICO E SIMULAÇÃO TÉRMICA
ver. 2015.04, M.M.Galarça  MÉTODO CLÁSSICO

Dúvidas, contate: marcelo.galarca@riogrande.ifrs.edu.br
____________________________________________________________
"""

import math
from scipy.optimize import fsolve

"""
------------------------------
VALORES DE ENTRADA CONHECIDOS
------------------------------
"""

rho = 1.2 # [kg/m³]
mu = 1.85e-5 # [Pa s]
L = 10.0 # [m]
Q = 1.330 # [m³/s]  <---- ESTA É A VAZÃO DO TRECHO EM QUE SE ESTÁ FAZENDO OS CÁLCULOS
theta = 0.0 # [deg] = ÂNGULO TOTAL DE CURVAS NO TRECHO
epsilon = 0.0001 # [m] = RUGOSIDADE ABSOLUTA

u = 6.0 # [m/s] <--- VALOR DE VELOCIDADE NO CONDUTO PRINCIPAL


"""
-------------------------------------------------
ROTINA DE CÁLCULOS DE PERDA DE CARGA E DIMENSÕES
-------------------------------------------------
"""

D = math.sqrt((4.0 * Q) / (math.pi * u)) 
Re = rho * u * D / mu
f_0 = math.pow(-1.8 * math.log10(math.pow(epsilon / (3.7 * D), 1.11) + 6.9 / Re), -2.0)
f = math.pow(-2.0 * math.log10(epsilon / (3.7 * D) + 2.51 / (Re * math.sqrt(f_0))), -2.0)

dP = (rho*f*L*u**2.0/D)
A = (math.pi*D**2)/4.0


"""
SAÍDAS DE VALORES
"""

print("D =", D, "[m]")
print("u = ", u, "[m/s]")
print("dP = ", dP, "[Pa]")
print("A = ", A, "[m²]")

