# -*- coding: utf-8 -*-
"""
_______________________________________________________________________
ROTINA DE CÁLCULO PARA DIMENSIONAMENTO DE DUTOS:
-----  RECUPERAÇÃO DA PRESSÃO ESTÁTICA -------

LATEST: LABORATÓRIO TERMOFLUIDODINÂMICO E SIMULAÇÃO TÉRMICA
ver. 2015.04, M.M.Galarça - MÉTODO CLÁSSICO

Dúvidas, contate: marcelo.galarca@riogrande.ifrs.edu.br
_______________________________________________________________________
"""

import math
from scipy.optimize import fsolve

"""
------------------------------
VALORES DE ENTRADA CONHECIDOS
------------------------------
"""

rho = 1.2 # [kg/m³]
mu = 1.85e-5 # [Pa s]
L_23 = 10.0 # [m]
Q_23 = 1.33 # [m³/s]
u_12 = 6.00 # [m/s]    <---- VELOCIDADE NO TRECHO ANTERIOR
theta = 0.0 # [deg]    <---- ANGULO TOTAL EM CURVAS NO TRECHO
R = 1.0 # [ ]          <---- FATOR DE RECUPERAÇÃO (75% - 100%)
epsilon = 0.0 # [m]
D_23_i = 0.7 # [m]     <---- CHUTE INICIAL DO DIÂMETRO DO TRECHO
u_23_i = 5.0 # [m/s]   <---- CHUTE INICIAL DA VELOCIDADE DO TRECHO

"""
__________________________________________________________________________

ROTINA DE CÁLCULOS COMPLEXOS

ATENÇÃO: NO CONJUNTO DE EQUAÇÕES ABAIXO NÃO DEVE SER ALTERADO NADA!
__________________________________________________________________________
"""   

Re = 0.0
f = 0.0
def residuals(initial):
    D_23 = initial[0]
    u_23 = initial[1]
    residual = [0.0, 0.0]
    global Re
    global f
    Re = rho * u_23 * D_23 / mu
    f_0 = math.pow(-1.8 * math.log10(math.pow(epsilon / (3.7 * D_23), 1.11) + 6.9 / Re), -2.0)
    f = math.pow(-2.0 * math.log10(epsilon / (3.7 * D_23) + 2.51 / (Re * math.sqrt(f_0))), -2.0)
    residual[0] = (f * L_23 / D_23 + 0.1 * theta / 90.0 + R) * u_23 ** 2.0 - R * u_12 ** 2.0
    residual[1] = D_23 - math.sqrt((4.0 * Q_23) / (math.pi * u_23))
    
    return residual


D_23, u_23 = fsolve(residuals, [D_23_i, u_23_i])
dP = (rho*f*L_23*u_23**2.0/D_23) # ESTA EQUAÇÃO DEVE SER DESLIGADA APÓS O CALCULO DO
                                 # PRIMEIRO TRECHO, POIS É A RECUPERAÇÃO APENAS DESTE
                                 # QUE É CONSIDERADA.SOMENTE É LIGADA DE NOVO PARA O
                                 # CÁLCULO DA CURVA (QUANDO EXISTIR)

A = (math.pi*D_23**2.0)/4.0

"""
__________________________________________________________________________
"""

"""
SAÍDA DE RESULTADOS
"""

print("D_2-3 =", D_23, "[m]")
print("u_2-3 = ", u_23, "[m/s]")
print("A =", A, "[m²]")
print("f =", f, "[]")
print("dP =", dP, "[Pa]")

print(residuals([D_23, u_23]))