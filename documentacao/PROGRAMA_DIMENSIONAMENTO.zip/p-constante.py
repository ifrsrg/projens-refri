# -*- coding: utf-8 -*-
"""
_______________________________________________________________________
ROTINA DE CÁLCULO PARA DIMENSIONAMENTO DE DUTOS:
---------  PERDA DE CARGA CONSTANTE  -----------

LATEST: LABORATÓRIO TERMOFLUIDODINÂMICO E SIMULAÇÃO TÉRMICA
ver. 2015(C).06, M.M.Galarça - MÉTODO ASHRAE

Dúvidas, contate: marcelo.galarca@riogrande.ifrs.edu.br
_______________________________________________________________________
"""

import math
from scipy.optimize import fsolve

"""
__________________________________________________________________________
O MÉTODO DE CÁLCULO PROPOSTO PELA ASHRAE É BASEADO EM MEDIÇÕES EMPÍRICAS
E CORRELAÇÕES DE APLICAÇÃO DIRETA, A PARTIR DE ÁBACOS, GRÁFICOS E TABELAS.

É POSSÍVEL DIMENSIONAR O SISTEMA DE DUTOS A CADA DOIS TRECHOS (NESTE
PROCEDIMENTO). LEIA O MANUAL DE INSTRUÇÕES ANTES DE INICIAR A UTILIZAÇÃO.
___________________________________________________________________________
"""

"""
------------------------------
VALORES DE ENTRADA CONHECIDOS
------------------------------
"""

rho = 1.2 # [kg/m³]
mu = 1.7e-5 # [Pa s]
L_1 = 1.0 # [m]
Q_1 = 1.000 # [m³/s]
Q_2 = 0.800  #[m³/s]
theta = 0.0 # [deg]
epsilon = 0.0001 # [m]

Tipo = 1 # DE ACORDO COM O TIPO DE SISTEMA. CONFORME DESCRITO ABAIXO

"""
TIPO DE SISTEMAS:

- (1) BAIXA VELOCIDADE (CONFORTO) :
    - PERDA DE CARGA UNITÁRIA EM TORNO DE 1.2 - 2.2 Pa/m
    - VELOCIDADE MÁX.: 12 m/s
    
- (2) ALTA VELOCIDADE (INDUSTRIAL) :
    - PERDA DE CARGA UNITÁRIA EM TORNO DE 4.0 - 6.0 Pa/m
    - VELOCIDADE MÁX.: 20 m/s
"""

#-------------------------------------------------------------------

"""
PARA DIMENSIONAR TODOS OS TRECHOS A PARTIR DA VAZÃO, TENDO A VELOCIDADE
COMO CONSEQUÊNCIA,A ROTINA DE CÁLCULOS ABAIXO É UTILIZADA.
É NECESSÁRIO VERIFICAR, NESTE CASO, SE A VELOCIDADE
RESULTANTE NÃO ESTÁ MUITO ACIMA DO RECOMENDADO PARA O CONFORTO (< 12m/s)
"""
if Tipo == 1:
    Q_1L = Q_1*1000.0  #[l/s]
    D_1 = 32.0*(math.pow(Q_1L, 0.38))/1000
    A_1 = (math.pi*D_1**2.0)/4.0
    u_1 = Q_1/A_1


    Q_2L = Q_2*1000.0 #[l/s]
    D_2 = 32.0*(math.pow(Q_2L, 0.38))/1000
    A_2 = (math.pi*D_1**2.0)/4.0
    u_2 = Q_2/A_2

else:
    Q_1L = Q_1*1000.0  #[l/s]
    D_1 = 25.0*(math.pow(Q_1L, 0.38))/1000
    A_1 = (math.pi*D_1**2.0)/4.0
    u_1 = Q_1/A_1


    Q_2L = Q_2*1000.0 #[l/s]
    D_2 = 25.0*(math.pow(Q_2L, 0.38))/1000
    A_2 = (math.pi*D_1**2.0)/4.0
    u_2 = Q_2/A_2
    
"""
------------------------------------------------------------------------
""" 
   
"""
ROTINA DE CÁLCULOS COMPLEXOS PARA PERDA DE CARGA
"""   
   
Re = rho * u_1 * D_1 / mu
f_0 = math.pow(-1.8 * math.log10(math.pow(epsilon / (3.7 * D_1), 1.11) + 6.9 / Re), -2.0)
f = math.pow(-2.0 * math.log10(epsilon / (3.7 * D_1) + 2.51 / (Re * math.sqrt(f_0))), -2.0)
dP_m = (f * L_1 / D_1 + 0.1 * theta / 90.0) * u_1 ** 2.0 * rho
    

"""
SAÍDAS DE VALORES
"""

#print("f =", f, "[ ]")
print("D_1 =", D_1, "[m]")
print("u_1 = ", u_1, "[m/s]")
print("A_1 = ", A_1, "[m²]")
print("D_2 =", D_2, "[m]")
print("u_2 = ", u_2, "[m/s]")
print("A_2 = ", A_2, "[m²]")
print("dP_m = ", dP_m, "[Pa/m]")
