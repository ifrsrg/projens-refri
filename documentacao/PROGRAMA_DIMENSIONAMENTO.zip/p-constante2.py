# -*- coding: utf-8 -*-
"""
___________________________________________________________

ROTINA DE CÁLCULO PARA DIMENSIONAMENTO DE DUTOS:
---------  PERDA DE CARGA CONSTANTE  -----------

LATEST: LABORATÓRIO TERMOFLUIDODINÂMICO E SIMULAÇÃO TÉRMICA
ver. 2015.04, M.M.Galarça  MÉTODO CLÁSSICO

Dúvidas, contate: marcelo.galarca@riogrande.ifrs.edu.br
____________________________________________________________
"""

import math
from scipy.optimize import fsolve

"""
------------------------------
VALORES DE ENTRADA CONHECIDOS
------------------------------
"""

rho = 1.2 # [kg/m³]
mu = 1.7e-5 # [Pa s]
L_23 = 1.0 # [m]
Q_23 = 0.800 # [m³/s]  <---- ESTA É A VAZÃO DO TRECHO EM QUE SE ESTÁ FAZENDO OS CÁLCULOS
theta = 0.0 # [deg] = ÂNGULO TOTAL DE CURVAS NO TRECHO
epsilon = 0.0001 # [m] = RUGOSIDADE ABSOLUTA



Q_1 = 1.000  # [m³/s] <--- ESTA É A VAZÃO ANTERIOR AO TRECHO
u_1 = 6.32 # [m/s] <--- AQUI, COLOCA-SE O VALOR CALCULADO NA ETAPA ANTERIOR
           # PARA A PRIMEIRA ETAPA, COLOCA-SE O VALOR DA VELOCIDADE INICAL
           # NO PRIMEIRO TRECHO.
"""
--------------------------------------------------------------------------
 PARA O CÁLCULO DA PERDA DE CARGA POR METRO, INICIALMENTE DEIXA-SE 'LIGADO'
 O CONJUNTO DE EQUAÇÕES ABAIXO, PARA O PRIMEIRO TRECHO
-------------------------------------------------------------------------- 
"""


D_1 = math.sqrt((4.0 * Q_1) / (math.pi * u_1)) 
Re_i = rho * u_1 * D_1 / mu
f_0_i = math.pow(-1.8 * math.log10(math.pow(epsilon / (3.7 * D_1), 1.11) + 6.9 / Re_i), -2.0)
f_i = math.pow(-2.0 * math.log10(epsilon / (3.7 * D_1) + 2.51 / (Re_i * math.sqrt(f_0_i))), -2.0)

dP_m1 = (f_i * L_23 / D_1 + 0.1 * theta / 90.0) * u_1 ** 2.0 * rho

D_23_i = D_1
u_23_i = u_1

"""
---------------------------------------------------------------------------

 A PARTIR DO CONHECIMENTO DAS DIMENSÕES DO PRIMEIRO TRECHO, E DA PERDA DE CARGA
 POR METRO ASSOCIADA A ELE, ANOTAM-SE OS VALORES ENCONTRADOS DE
 dP_m1; D_1 e u_1. 'DESLIGA-SE' O CONJUNTO DE EQUAÇÕES ACIMA E 'LIGA-SE
 O CONJUNTO ABAIXO, COM OS RESPECTIVOS VALORES SUBSTITUÍDOS
 
 ATENÇÃO: NA PRIMEIRA ETAPA O CONJUNTO ABAIXO DEVE SER 'DESLIGADO'!!
----------------------------------------------------------------------------
"""

#dP_m1 = 1.54 # [Pa/m]<--- AQUI, COLOCA-SE O VALOR CALCULADO NA PRIMEIRA ETAPA SOMENTE!
#D_23_i = 0.449  # [m]<--- AQUI, COLCA-SE O VALOR CALCULADO NA ETAPA ANTERIOR
u_23_i = u_1  # <--- ESTE CAMPO PERMANECE SEMPRE 'LIGADO'!

"""
-----------------------------
ROTINA DE CÁLCULOS COMPLEXOS
-----------------------------
"""

def residuals(initial):
    D_23 = initial[0]
    u_23 = initial[1]
    residual = [0.0, 0.0]
    global Re
    global f
    Re = rho * u_23 * D_23 / mu
    f_0 = math.pow(-1.8 * math.log10(math.pow(epsilon / (3.7 * D_23), 1.11) + 6.9 / Re), -2.0)
    f = math.pow(-2.0 * math.log10(epsilon / (3.7 * D_23) + 2.51 / (Re * math.sqrt(f_0))), -2.0)
    residual[0] = (f * L_23 / D_23 + 0.1 * theta / 90.0)*u_23**2.0 - dP_m1    
    residual[1] = D_23 - math.sqrt((4.0 * Q_23) / (math.pi * u_23))
  
    
    return residual


D_23, u_23 = fsolve(residuals, [D_23_i, u_23_i])

"""
SAÍDAS DE VALORES
"""

print("D_2-3 =", D_23, "[m]")
print("u_2-3 = ", u_23, "[m/s]")
print ("D_1 =", D_1, "[m]")      # ESTA LINHA PODE SER DESLIGADA APÓS O PRIMEIRO TRECHO
                                 # TER SIDO CALCULADO
print("dP_m1 = ", dP_m1, "[Pa/m]")

print(residuals([D_23, u_23]))